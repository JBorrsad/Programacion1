
/**
 *   
 */
public class Punto3D   
{
 
     

    /**
     * Constructor  
     */
    public Punto3D()    {
        
    }
 
    

    

}
