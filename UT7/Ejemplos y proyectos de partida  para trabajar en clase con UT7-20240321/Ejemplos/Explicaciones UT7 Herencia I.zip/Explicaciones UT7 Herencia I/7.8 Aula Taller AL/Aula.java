
/**
 *  
 * 
 * @author  
 * @version  
 */
public class Aula
{
     
    

    /**
     * Constructor  
     */
    public Aula(            )    {
         
         
    }

    /**
     *  accesor para el nombre
     */
    public String getNombre()    {
         
    }
    
    /**
     *  accesor para los pupitres
     */
    public int getPupitres()    {
          
    }
    
      /**
     *  mutador para el nombre
     */
    public void setNombre(String nombre)    {
        
    }
    
    /**
     *  mutador para los pupitres
     */
    public void setPupitres(int pupitres)   {
         this.pupitres = pupitres;
    }
    
    /**
     * 
     */
    public  void mostrar()    {
       
    }

}
