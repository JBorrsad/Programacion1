
/**
 * 
 */
public class AulaTaller  
{
     
   

    /**
     * Constructor  
     */
    public AulaTaller(   )    {
         
    }

    /**
     *  
     * 
     * 
     */
    public void visualizar()    {
         
        
        
        
        
    }
}
