public class AppABddArticulo {
    public static void main(String[] args) {
        BaseDatos bd = new BaseDatos();

    }
}
