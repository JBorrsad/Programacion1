package es.mariaanasanz.ut7.ejemplos;

import es.mariaanasanz.ut7.ejemplos.nivel1.abuelo.Persona;
import es.mariaanasanz.ut7.ejemplos.nivel2.padre.Alumno;
import es.mariaanasanz.ut7.ejemplos.nivel2.padre.Profesor;
import es.mariaanasanz.ut7.ejemplos.nivel3.hijo.AlumnoPrimaria;
import es.mariaanasanz.ut7.ejemplos.nivel3.hijo.AlumnoSecundaria;

import java.util.ArrayList;

public class Main {

    public static ArrayList<Persona> personas = new ArrayList<>();

    public static void main(String[] args) {
        poblarDatos();
        recorrerPersonas();
    }

    public static void recorrerPersonas(){
        // Creamos los contadores
        int contadorPersonas = 0;
        int contadorProfesores = 0;
        int contadorAlumnos = 0;
        int contadorAlumnosPrimaria = 0;
        int contadorAlumnosSecundaria = 0;

        // Recorremos el ArrayList de personas
        for (Persona persona : personas) {
            // Comprobamos el tipo de la instancia y actualizamos el contador correspondiente
            if (persona instanceof Persona) {
                contadorPersonas++;
            } else if (persona instanceof Profesor) {
                contadorProfesores++;
            } else if (persona instanceof Alumno) {
                contadorAlumnos++;
                if (persona instanceof AlumnoPrimaria) {
                    contadorAlumnosPrimaria++;
                } else if (persona instanceof AlumnoSecundaria) {
                    contadorAlumnosSecundaria++;
                }
            }
        }

        // Mostramos los resultados por consola
        System.out.println("Hay " + contadorPersonas + " instancias de Persona.");
        System.out.println("Hay " + contadorProfesores + " instancias de Profesor.");
        System.out.println("Hay " + contadorAlumnos + " instancias de Alumno, de las cuales:");
        System.out.println("  - " + contadorAlumnosPrimaria + " son de AlumnoPrimaria.");
        System.out.println("  - " + contadorAlumnosSecundaria + " son de AlumnoSecundaria.");
    }

    public static void poblarDatos(){

        // Añadimos las instancias al ArrayList
        personas.add(new Persona(25, "Juan", "12345678"));
        personas.add(new Persona(30, "Ana", "87654321"));
        personas.add(new Persona(42, "Pedro", "45678901"));
        personas.add(new Persona(18, "María", "10987654"));
        personas.add(new Persona(50, "Luis", "98765432"));

        // Creamos tres instancias de la clase Profesor
        Profesor profesor1 = new Profesor(35, "Carlos", "24681357", "Matemáticas");
        Profesor profesor2 = new Profesor(40, "María", "13579246", "Historia");
        Profesor profesor3 = new Profesor(45, "Pedro", "35792468", "Física");

        // Añadimos las instancias al ArrayList
        personas.add(profesor1);
        personas.add(profesor2);
        personas.add(profesor3);

        // Creamos siete instancias de la clase Alumno
        Alumno alumno1 = new Alumno(18, "Laura", "46789213", "Primero de ESO");
        Alumno alumno2 = new Alumno(16, "Antonio", "86421379", "Tercero de ESO");
        Alumno alumno3 = new Alumno(19, "Isabel", "21453678", "Segundo de Bachillerato");
        Alumno alumno4 = new Alumno(17, "Juan", "57389612", "Primero de Bachillerato");
        Alumno alumno5 = new Alumno(15, "Lucía", "91678453", "Segundo de ESO");
        Alumno alumno6 = new Alumno(14, "David", "82319765", "Tercero de ESO");
        Alumno alumno7 = new Alumno(18, "Marta", "34652189", "Ciclo Formativo de Grado Superior");

        // Añadimos las instancias al ArrayList
        personas.add(alumno1);
        personas.add(alumno2);
        personas.add(alumno3);
        personas.add(alumno4);
        personas.add(alumno5);
        personas.add(alumno6);
        personas.add(alumno7);

        // Creamos cinco instancias de la clase AlumnoPrimaria
        AlumnoPrimaria alumnoPrim1 = new AlumnoPrimaria(7, "Pablo", "54879236", "Segundo de Primaria", false);
        AlumnoPrimaria alumnoPrim2 = new AlumnoPrimaria(8, "Carmen", "91547628", "Tercero de Primaria", true);
        AlumnoPrimaria alumnoPrim3 = new AlumnoPrimaria(6, "Javier", "34689157", "Primero de Primaria", false);
        AlumnoPrimaria alumnoPrim4 = new AlumnoPrimaria(7, "Sofía", "72631584", "Segundo de Primaria", true);
        AlumnoPrimaria alumnoPrim5 = new AlumnoPrimaria(8, "María", "25346718", "Tercero de Primaria", false);

        // Añadimos las instancias al ArrayList
        personas.add(alumnoPrim1);
        personas.add(alumnoPrim2);
        personas.add(alumnoPrim3);
        personas.add(alumnoPrim4);
        personas.add(alumnoPrim5);

        // Creamos tres instancias de la clase AlumnoSecundaria
        AlumnoSecundaria alumnoSec1 = new AlumnoSecundaria(14, "Carlos", "34127659", "Primero de ESO", true);
        AlumnoSecundaria alumnoSec2 = new AlumnoSecundaria(15, "Lucía", "93671284", "Segundo de ESO", false);
        AlumnoSecundaria alumnoSec3 = new AlumnoSecundaria(13, "Andrés", "25863971", "Primero de ESO", true);

        // Añadimos las instancias al ArrayList
        personas.add(alumnoSec1);
        personas.add(alumnoSec2);
        personas.add(alumnoSec3);
    }

}
