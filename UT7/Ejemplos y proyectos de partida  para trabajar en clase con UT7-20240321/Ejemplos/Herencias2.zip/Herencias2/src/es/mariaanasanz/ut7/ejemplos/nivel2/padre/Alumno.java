package es.mariaanasanz.ut7.ejemplos.nivel2.padre;

import es.mariaanasanz.ut7.ejemplos.nivel1.abuelo.Persona;

public class Alumno extends Persona {

    protected String curso;

    public Alumno(int edad, String nombre, String dni, String curso) {
        super(edad, nombre, dni);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "curso='" + curso + '\'' +
                ", edad=" + edad +
                ", nombre='" + nombre + '\'' +
                ", dni='" + dni + '\'' +
                '}';
    }
}
