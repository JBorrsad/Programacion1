package es.mariaanasanz.ut7.ejemplos.nivel2.padre;

import es.mariaanasanz.ut7.ejemplos.nivel1.abuelo.Persona;

public class Profesor extends Persona {

    protected String materia;

    public Profesor(int edad, String nombre, String dni, String materia) {
        super(edad, nombre, dni);
        this.materia = materia;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    @Override
    public String toString() {
        return "Profesor{" +
                "materia='" + materia + '\'' +
                ", edad=" + edad +
                ", nombre='" + nombre + '\'' +
                ", dni='" + dni + '\'' +
                '}';
    }
}
