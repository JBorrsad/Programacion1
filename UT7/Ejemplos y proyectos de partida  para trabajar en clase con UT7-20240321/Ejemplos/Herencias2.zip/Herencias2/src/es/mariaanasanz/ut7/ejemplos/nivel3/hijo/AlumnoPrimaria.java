package es.mariaanasanz.ut7.ejemplos.nivel3.hijo;

import es.mariaanasanz.ut7.ejemplos.nivel2.padre.Alumno;

public class AlumnoPrimaria extends Alumno {

    boolean lactante;

    public AlumnoPrimaria(int edad, String nombre, String dni, String curso, boolean lactante) {
        super(edad, nombre, dni, curso);
        this.lactante = lactante;
    }

    public boolean isLactante() {
        return lactante;
    }

    public void setLactante(boolean lactante) {
        this.lactante = lactante;
    }

    @Override
    public String toString() {
        return "AlumnoPrimaria{" +
                "lactante=" + lactante +
                ", curso='" + curso + '\'' +
                ", edad=" + edad +
                ", nombre='" + nombre + '\'' +
                ", dni='" + dni + '\'' +
                '}';
    }
}
