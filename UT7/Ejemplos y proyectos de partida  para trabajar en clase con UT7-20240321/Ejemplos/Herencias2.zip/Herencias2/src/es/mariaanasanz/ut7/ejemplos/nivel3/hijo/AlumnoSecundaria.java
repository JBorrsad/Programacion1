package es.mariaanasanz.ut7.ejemplos.nivel3.hijo;

import es.mariaanasanz.ut7.ejemplos.nivel2.padre.Alumno;

public class AlumnoSecundaria extends Alumno {

    boolean edadDelPavo;

    public AlumnoSecundaria(int edad, String nombre, String dni, String curso, boolean edadDelPavo) {
        super(edad, nombre, dni, curso);
        this.edadDelPavo = edadDelPavo;
    }

    public boolean isEdadDelPavo() {
        return edadDelPavo;
    }

    public void setEdadDelPavo(boolean edadDelPavo) {
        this.edadDelPavo = edadDelPavo;
    }

    @Override
    public String toString() {
        return "AlumnoSecundaria{" +
                "edadDelPavo=" + edadDelPavo +
                ", curso='" + curso + '\'' +
                ", edad=" + edad +
                ", nombre='" + nombre + '\'' +
                ", dni='" + dni + '\'' +
                '}';
    }
}
