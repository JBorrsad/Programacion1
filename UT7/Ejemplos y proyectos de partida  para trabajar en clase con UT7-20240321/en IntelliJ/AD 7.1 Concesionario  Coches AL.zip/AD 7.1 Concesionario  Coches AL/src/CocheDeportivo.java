/**
 *  clase CocheDeportivo 
 *
 */

public class CocheDeportivo {
    //sin atributos, solo los heredados

    public CocheDeportivo() {

    }


}
      
