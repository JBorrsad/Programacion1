/**
 * Clase CocheEconomico 
 *
 */

public class CocheEconomico {
    // sin atributos, solo los heredados
    public CocheEconomico() {

    }


}


