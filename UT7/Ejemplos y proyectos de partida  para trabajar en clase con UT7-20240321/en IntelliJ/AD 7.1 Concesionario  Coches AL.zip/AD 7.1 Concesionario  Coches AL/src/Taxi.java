/**
 * Representa a un taxi
 */

public class Taxi {

    public Taxi() {

    }

}
