/**
 * Clase para probar la jerarquía de herencia
 *
 */
public class AppCuenta {


    public static void main(String[] args) {


    }

}
